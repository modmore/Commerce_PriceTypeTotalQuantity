<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'MIT License

Copyright (c) 2020

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
',
    'readme' => 'Price Type: Total Quantity for Commerce
------------------------

"Price Type: Total Quantity" allows a discount to be applied to all the items in your cart when a certain quantity is reached.
This threshold can be specified in the Pricing tab when editing products.

',
    'changelog' => 'Price Type: Total Quantity for Commerce 1.0.0-pl
---------------------------------
Released on 30/04/2021

- First release
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '255cfbfc88f08a7bf82efb1e3cfcc67c',
      'native_key' => 'commerce_pricetypetotalquantity',
      'filename' => 'modNamespace/9c1847ab40e8eb1ae01e43df1713c927.vehicle',
      'namespace' => 'commerce_pricetypetotalquantity',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '5edbd7a157bdb5d1fd26fc7955875f6b',
      'native_key' => '5edbd7a157bdb5d1fd26fc7955875f6b',
      'filename' => 'xPDOFileVehicle/9c80f7c5e02c3e146f14f061d910b66e.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ab3ad9eaec3c59893e423c707209aecc',
      'native_key' => NULL,
      'filename' => 'modCategory/ec546e1a8b895328962ee3026c82b927.vehicle',
      'namespace' => 'commerce_pricetypetotalquantity',
    ),
  ),
);