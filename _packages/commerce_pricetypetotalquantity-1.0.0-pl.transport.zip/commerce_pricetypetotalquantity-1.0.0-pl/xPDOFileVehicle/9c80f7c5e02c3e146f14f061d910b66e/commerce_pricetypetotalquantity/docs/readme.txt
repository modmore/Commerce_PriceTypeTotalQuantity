Price Type: Total Quantity for Commerce
------------------------

"Price Type: Total Quantity" allows a discount to be applied to all the items in your cart when a certain quantity is reached.
This threshold can be specified in the Pricing tab when editing products.

